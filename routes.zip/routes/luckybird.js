const express = require('express')
const multer = require('multer')
const router = express.Router()

const { pool } = require('../db')
const cloudinary = require('../config/cloudinary')
const { requirePermission } = require('../middleware/auth')

const luckyBirdGiveUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
        const allowed = Boolean(file?.mimetype?.startsWith('image/'))
        cb(allowed ? null : new Error('Only images are allowed.'), allowed)
    }
})

const luckyBirdGiveOk = (res, data, message = 'Success.') => res.json({
    success: true,
    code: 20000,
    message,
    data
})

const luckyBirdGiveFail = (res, http, message) => res.status(http).json({
    success: false,
    code: http * 100,
    message
})

const luckyBirdGiveValidId = value =>
    Number.isSafeInteger(Number(value)) && Number(value) > 0

const uploadLuckyBirdImage = buffer => new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
        { folder: 'luckyBird-awards', resource_type: 'image' },
        (error, result) => error ? reject(error) : resolve(result)
    )
    stream.end(buffer)
})

async function activeLuckyBirdGiveSession(db, req, lock = false) {
    const userId = Number(req.authUser?.id || 0)

    if (!luckyBirdGiveValidId(userId)) return null

    const result = await db.query(`
        SELECT es."ID", es."UserId", es."LocationId", es."ClockIn"
        FROM "EmployeeSession" es
        WHERE es."UserId"=$1
          AND es."ClockOut" IS NULL
        ORDER BY es."ClockIn" DESC
        LIMIT 1 ${lock ? 'FOR UPDATE OF es' : ''}
    `, [userId])

    return result.rows[0] || null
}

async function luckyBirdGiveSessionBalance(db, session) {
    const result = await db.query(`
        WITH cash AS (
            SELECT
                COALESCE(SUM("Amount") FILTER (WHERE "Type" IN ('OPENING','OPENING_TRANSFER')),0) opening,
                COALESCE(SUM("Amount") FILTER (WHERE "Type" IN ('CASH_RECEIVED','TRANSFER_IN')),0) received,
                COALESCE(SUM("Amount") FILTER (WHERE "Type"='TRANSFER_OUT'),0) transfer_out,
                COALESCE(SUM("Amount") FILTER (WHERE "Type"='EXPENSE'),0) expenses,
                COALESCE(SUM("Amount") FILTER (WHERE "Type"='OWNER_WITHDRAWAL'),0) withdrawals,
                COUNT("ID")::integer entries
            FROM "SessionCashTransactions"
            WHERE "SessionId"=$1
        ),
        points AS (
            SELECT COALESCE(SUM(cm."Points"),0) total
            FROM "CustomerMatch" cm
            WHERE cm."EmployeeSessionId"=$1
        ),
        raffles AS (
            SELECT COALESCE(SUM(r."WinningAmount"),0) total
            FROM "Raffles" r
            WHERE r."EmployeeSessionId"=$1
              AND r."Status"='WINNER'
        ),
        tickets AS (
            SELECT COALESCE(SUM(t."Amount"),0) total
            FROM "TicketOuts" t
            WHERE t."EmployeeSessionId"=$1
        ),
        luckyBirds AS (
            SELECT COALESCE(SUM(b."Amount"),0) total
            FROM "LuckyBirdAwards" b
            WHERE b."EmployeeSessionId"=$1
        ),
        lucky_birds AS (
            SELECT COALESCE(SUM(lb."Amount"),0) total
            FROM "LuckyBirdAwards" lb
            WHERE lb."EmployeeSessionId"=$1
        )
        SELECT
            (
                cash.opening
                + cash.received
                - cash.transfer_out
                - cash.expenses
                - cash.withdrawals
                - points.total
                - raffles.total
                - tickets.total
                - luckyBirds.total
                - lucky_birds.total
            )::numeric(14,2) balance,
            cash.entries
        FROM cash
        CROSS JOIN points
        CROSS JOIN raffles
        CROSS JOIN tickets
        CROSS JOIN luckyBirds
        CROSS JOIN lucky_birds
    `, [session.ID])

    return result.rows[0]
}

const activeLuckyBirdScheduleExistsSql = luckyBirdAlias => `
    EXISTS (
        SELECT 1
        FROM "LuckyBirdScheduleBlock" sb
        JOIN "LuckyBirdScheduleDay" sd
          ON sd."ScheduleBlockId"=sb."ID"
        WHERE sb."LuckyBirdId"=${luckyBirdAlias}."ID"
          AND (
            (
                sb."IsAllDay"=true
                AND sd."DayOfWeek"=
                    EXTRACT(
                        ISODOW FROM (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')
                    )::integer
            )
            OR
            (
                sb."IsAllDay"=false
                AND sb."EndDayOffset"=0
                AND sd."DayOfWeek"=
                    EXTRACT(
                        ISODOW FROM (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')
                    )::integer
                AND (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')::time >= sb."StartTime"
                AND (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')::time <= sb."EndTime"
            )
            OR
            (
                sb."IsAllDay"=false
                AND sb."EndDayOffset"=1
                AND sd."DayOfWeek"=
                    EXTRACT(
                        ISODOW FROM (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')
                    )::integer
                AND (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')::time >= sb."StartTime"
            )
            OR
            (
                sb."IsAllDay"=false
                AND sb."EndDayOffset"=1
                AND sd."DayOfWeek"=(
                    (
                        EXTRACT(
                            ISODOW FROM (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')
                        )::integer + 5
                    ) % 7
                ) + 1
                AND (CURRENT_TIMESTAMP AT TIME ZONE 'America/Chicago')::time <= sb."EndTime"
            )
          )
    )
`


// ============================================================
// VALIDATE LUCKY BIRD PAYLOAD
// ============================================================

function validateLuckyBirdPayload({
    name,
    locationId,
    payouts = [],
    scheduleBlocks = [],
    requireLocation = true
}) {
    if (!name?.trim()) {
        return 'Lucky Bird name is required.'
    }

    if (requireLocation && !locationId) {
        return 'Location is required.'
    }

    if (!Array.isArray(payouts) || payouts.length === 0) {
        return 'At least one payout is required.'
    }

    for (const payout of payouts) {
        if (!payout.description?.trim()) {
            return 'Each payout requires a description.'
        }

        const amount = Number(payout.amount)

        if (Number.isNaN(amount) || amount < 0) {
            return 'Each payout must have a valid non-negative amount.'
        }
    }

    if (
        !Array.isArray(scheduleBlocks) ||
        scheduleBlocks.length === 0
    ) {
        return 'At least one schedule block is required.'
    }

    for (const block of scheduleBlocks) {
        if (
            !Array.isArray(block.days) ||
            block.days.length === 0
        ) {
            return 'Each schedule block requires at least one day.'
        }

        for (const day of block.days) {
            const dayNumber = Number(day)

            if (
                !Number.isInteger(dayNumber) ||
                dayNumber < 1 ||
                dayNumber > 7
            ) {
                return 'Invalid schedule day.'
            }
        }

        if (!block.isAllDay) {
            if (!block.startTime || !block.endTime) {
                return 'Start and end time are required for timed schedule blocks.'
            }

            const endDayOffset =
                Number(block.endDayOffset ?? 0)

            if (
                endDayOffset !== 0 &&
                endDayOffset !== 1
            ) {
                return 'End day offset must be 0 or 1.'
            }

            /*
             * Same-day blocks should end after they start.
             *
             * Example:
             * 3:00 PM -> 4:00 PM = valid
             *
             * Overnight:
             * 8:00 PM -> 12:02 AM must use EndDayOffset = 1
             */
            if (
                endDayOffset === 0 &&
                block.endTime <= block.startTime
            ) {
                return 'End time must be after start time for a same-day schedule.'
            }
        }
    }

    return null
}

// ============================================================
// INSERT PAYOUTS
// ============================================================

async function insertLuckyBirdPayouts(
    client,
    luckyBirdId,
    payouts
) {
    for (
        let index = 0;
        index < payouts.length;
        index++
    ) {
        const payout =
            payouts[index]

        await client.query(
            `
            INSERT INTO "LuckyBirdPayout"
            (
                "LuckyBirdId",
                "Description",
                "Amount",
                "SortOrder"
            )
            VALUES
            (
                $1,
                $2,
                $3,
                $4
            )
            `,
            [
                luckyBirdId,
                payout.description.trim(),
                Number(payout.amount),
                index
            ]
        )
    }
}

// ============================================================
// INSERT SCHEDULE BLOCKS
// ============================================================

async function insertLuckyBirdScheduleBlocks(
    client,
    luckyBirdId,
    scheduleBlocks
) {
    for (
        let index = 0;
        index < scheduleBlocks.length;
        index++
    ) {
        const block =
            scheduleBlocks[index]

        const isAllDay =
            Boolean(block.isAllDay)

        const endDayOffset =
            isAllDay
                ? 0
                : Number(
                    block.endDayOffset ?? 0
                )

        const blockResult =
            await client.query(
                `
                INSERT INTO "LuckyBirdScheduleBlock"
                (
                    "LuckyBirdId",
                    "IsAllDay",
                    "StartTime",
                    "EndTime",
                    "EndDayOffset",
                    "SortOrder"
                )
                VALUES
                (
                    $1,
                    $2,
                    $3,
                    $4,
                    $5,
                    $6
                )
                RETURNING
                    "ID" AS "id"
                `,
                [
                    luckyBirdId,
                    isAllDay,
                    isAllDay
                        ? null
                        : block.startTime,
                    isAllDay
                        ? null
                        : block.endTime,
                    endDayOffset,
                    index
                ]
            )

        const scheduleBlockId =
            blockResult.rows[0].id

        const uniqueDays = [
            ...new Set(
                block.days.map(Number)
            )
        ]

        for (const day of uniqueDays) {
            await client.query(
                `
                INSERT INTO "LuckyBirdScheduleDay"
                (
                    "ScheduleBlockId",
                    "DayOfWeek"
                )
                VALUES
                (
                    $1,
                    $2
                )
                `,
                [
                    scheduleBlockId,
                    day
                ]
            )
        }
    }
}

// ============================================================
// GET ACTIVE LUCKY BIRDES RIGHT NOW
//
// IMPORTANT:
// This route is deliberately above /:id.
//
// Supports:
// - All-day schedules
// - Same-day schedules
// - Overnight schedules
//
// Example:
// Monday 8 PM -> Tuesday 12:02 AM
//
// At Tuesday 12:01 AM we must look for a Monday schedule.
// ============================================================

router.get(
    '/active/current/list',
    requirePermission('luckybird.read'),
    async (req, res) => {
        try {
            const locationId =
                Number(
                    req.query.locationid
                )

            if (!locationId) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Location is required.'
                })
            }

            const result =
                await pool.query(
                    `
                    SELECT DISTINCT
                        b."ID" AS "id",
                        b."Name" AS "name",
                        b."IsActive" AS "isActive"

                    FROM "LuckyBird" b

                    INNER JOIN
                        "LuckyBirdScheduleBlock" sb
                            ON sb."LuckyBirdId" = b."ID"

                    INNER JOIN
                        "LuckyBirdScheduleDay" sd
                            ON sd."ScheduleBlockId" = sb."ID"

                    WHERE
                        b."LocationId" = $1

                        AND
                        b."IsActive" = true

                        AND
                        (
                            (
                                sb."IsAllDay" = true

                                AND

                                sd."DayOfWeek" =
                                    EXTRACT(
                                        ISODOW FROM NOW()
                                    )::integer
                            )

                            OR

                            (
                                sb."IsAllDay" = false

                                AND
                                sb."EndDayOffset" = 0

                                AND
                                sd."DayOfWeek" =
                                    EXTRACT(
                                        ISODOW FROM NOW()
                                    )::integer

                                AND
                                CURRENT_TIME >=
                                    sb."StartTime"

                                AND
                                CURRENT_TIME <=
                                    sb."EndTime"
                            )

                            OR

                            (
                                sb."IsAllDay" = false

                                AND
                                sb."EndDayOffset" = 1

                                AND
                                sd."DayOfWeek" =
                                    EXTRACT(
                                        ISODOW FROM NOW()
                                    )::integer

                                AND
                                CURRENT_TIME >=
                                    sb."StartTime"
                            )

                            OR

                            (
                                sb."IsAllDay" = false

                                AND
                                sb."EndDayOffset" = 1

                                AND
                                sd."DayOfWeek" =
                                (
                                    (
                                        EXTRACT(
                                            ISODOW FROM NOW()
                                        )::integer + 5
                                    ) % 7
                                ) + 1

                                AND
                                CURRENT_TIME <=
                                    sb."EndTime"
                            )
                        )

                    ORDER BY
                        b."Name"
                    `,
                    [
                        locationId
                    ]
                )

            return res.status(200).json({
                success: true,
                code: 20000,
                message:
                    'Active luckyBirds retrieved successfully.',
                data:
                    result.rows
            })
        } catch (error) {
            console.error(
                'Get current active luckyBirds error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to retrieve active luckyBirds.'
            })
        }
    }
)


// ============================================================
// LUCKY BIRD GIVE FLOW - CURRENT EMPLOYEE SESSION STATE
// ============================================================

router.get(
    '/give/state',
    requirePermission('clock.read'),
    async (req, res) => {
        try {
            const session = await activeLuckyBirdGiveSession(pool, req)

            if (!session) {
                return luckyBirdGiveFail(res, 409, 'Clock in before giving a Lucky Bird.')
            }

            const balance = await luckyBirdGiveSessionBalance(pool, session)

            return luckyBirdGiveOk(res, {
                sessionId: session.ID,
                locationId: session.LocationId,
                balance: Number(balance.balance || 0),
                cashReady: Number(balance.entries || 0) > 0
            })
        } catch (error) {
            console.error('Lucky Bird give state:', error)
            return luckyBirdGiveFail(res, 500, 'Unable to load Lucky Bird status.')
        }
    }
)

// ============================================================
// LUCKY BIRD GIVE FLOW - MACHINE LOOKUP
// ============================================================

router.get(
    '/give/machine',
    requirePermission('clock.read'),
    async (req, res) => {
        try {
            const session = await activeLuckyBirdGiveSession(pool, req)

            if (!session) {
                return luckyBirdGiveFail(res, 409, 'Clock in before giving a Lucky Bird.')
            }

            const machineNumber = String(req.query.machinenumber || '').trim()

            if (!machineNumber) {
                return luckyBirdGiveFail(res, 400, 'Machine number is required.')
            }

            const result = await pool.query(`
                SELECT
                    m."ID" AS id,
                    m."MachineNumber" AS "machineNumber",
                    mt."TypeName" AS "machineType",
                    ms."Description" AS status
                FROM "Machines" m
                LEFT JOIN "MachineTypes" mt
                  ON mt."ID"=m."MachineTypeId"
                LEFT JOIN "MachineStatus" ms
                  ON ms."ID"=m."StatusId"
                WHERE m.locationid=$1
                  AND m."MachineNumber"::text=$2
                LIMIT 1
            `, [session.LocationId, machineNumber])

            if (!result.rowCount) {
                return luckyBirdGiveFail(
                    res,
                    404,
                    `Machine #${machineNumber} was not found at this location.`
                )
            }

            return luckyBirdGiveOk(res, result.rows[0])
        } catch (error) {
            console.error('Lucky Bird give machine:', error)
            return luckyBirdGiveFail(res, 500, 'Unable to find machine.')
        }
    }
)

// ============================================================
// LUCKY BIRD GIVE FLOW - ACTIVE LUCKY BIRDES + PAYOUT OPTIONS
// Employee flow intentionally uses clock.read, not luckybird.read.
// ============================================================

router.get(
    '/give/active/list',
    requirePermission('clock.read'),
    async (req, res) => {
        try {
            const session = await activeLuckyBirdGiveSession(pool, req)

            if (!session) {
                return luckyBirdGiveFail(res, 409, 'Clock in before giving a Lucky Bird.')
            }

            const result = await pool.query(`
                SELECT
                    b."ID" AS id,
                    b."Name" AS name,
                    COALESCE(
                        JSONB_AGG(
                            JSONB_BUILD_OBJECT(
                                'id', bp."ID",
                                'description', bp."Description",
                                'amount', bp."Amount"::double precision,
                                'sortOrder', bp."SortOrder"
                            )
                            ORDER BY bp."SortOrder", bp."ID"
                        ) FILTER (WHERE bp."ID" IS NOT NULL),
                        '[]'::jsonb
                    ) AS payouts
                FROM "LuckyBird" b
                LEFT JOIN "LuckyBirdPayout" bp
                  ON bp."LuckyBirdId"=b."ID"
                 AND bp."Amount" > 0
                WHERE b."LocationId"=$1
                  AND b."IsActive"=true
                  AND ${activeLuckyBirdScheduleExistsSql('b')}
                GROUP BY b."ID", b."Name"
                HAVING COUNT(bp."ID") > 0
                ORDER BY b."Name", b."ID"
            `, [session.LocationId])

            return luckyBirdGiveOk(
                res,
                result.rows,
                'Active luckyBirds retrieved successfully.'
            )
        } catch (error) {
            console.error('Lucky Bird give active list:', error)
            return luckyBirdGiveFail(res, 500, 'Unable to load active luckyBirds.')
        }
    }
)

// ============================================================
// LUCKY BIRD GIVE FLOW - SAVE AWARD
// LuckyBirdAwards is the expense source of truth.
// No SessionCashTransactions EXPENSE row is created.
// ============================================================

router.post(
    '/give/save',
    requirePermission('clock.update'),
    luckyBirdGiveUpload.single('image'),
    async (req, res) => {
        const client = await pool.connect()

        try {
            const luckyBirdId = Number(req.body.luckyBirdid)
            const payoutId = Number(req.body.payoutid)
            const machineId = Number(req.body.machineid)
            const customerId = Number(req.body.customerid)

            if (!luckyBirdGiveValidId(luckyBirdId)) {
                return luckyBirdGiveFail(res, 400, 'Select a valid luckybird.')
            }

            if (!luckyBirdGiveValidId(payoutId)) {
                return luckyBirdGiveFail(res, 400, 'Select a valid payout amount.')
            }

            if (!luckyBirdGiveValidId(machineId)) {
                return luckyBirdGiveFail(res, 400, 'Select a valid machine.')
            }

            if (!luckyBirdGiveValidId(customerId)) {
                return luckyBirdGiveFail(res, 400, 'Select a valid customer.')
            }

            if (!req.file) {
                return luckyBirdGiveFail(res, 400, 'Capture a photo for the Lucky Bird.')
            }

            await client.query('BEGIN')

            const session = await activeLuckyBirdGiveSession(client, req, true)

            if (!session) {
                await client.query('ROLLBACK')
                return luckyBirdGiveFail(res, 409, 'Clock in before giving a Lucky Bird.')
            }

            const machine = await client.query(`
                SELECT "ID", "MachineNumber"
                FROM "Machines"
                WHERE "ID"=$1
                  AND locationid=$2
                FOR UPDATE
            `, [machineId, session.LocationId])

            if (!machine.rowCount) {
                await client.query('ROLLBACK')
                return luckyBirdGiveFail(
                    res,
                    400,
                    'Selected machine is not valid for your location.'
                )
            }

            const customer = await client.query(`
                SELECT "ID", "Firstname", "Lastname"
                FROM "Customer"
                WHERE "ID"=$1
                  AND "locationid"=$2
                  AND "IsActive"=true
                LIMIT 1
            `, [customerId, session.LocationId])

            if (!customer.rowCount) {
                await client.query('ROLLBACK')
                return luckyBirdGiveFail(
                    res,
                    400,
                    'Selected customer is not valid for your location.'
                )
            }

            // Re-check luckyBird, payout and schedule at the moment of save.
            const payout = await client.query(`
                SELECT
                    b."ID" AS "luckyBirdId",
                    b."Name" AS "luckyBirdName",
                    bp."ID" AS "payoutId",
                    bp."Description" AS "payoutDescription",
                    bp."Amount"::numeric(14,2) AS amount
                FROM "LuckyBird" b
                JOIN "LuckyBirdPayout" bp
                  ON bp."LuckyBirdId"=b."ID"
                WHERE b."ID"=$1
                  AND bp."ID"=$2
                  AND b."LocationId"=$3
                  AND b."IsActive"=true
                  AND bp."Amount" > 0
                  AND ${activeLuckyBirdScheduleExistsSql('b')}
                LIMIT 1
            `, [luckyBirdId, payoutId, session.LocationId])

            if (!payout.rowCount) {
                await client.query('ROLLBACK')
                return luckyBirdGiveFail(
                    res,
                    409,
                    'This lucky bird or payout is no longer active for the current schedule.'
                )
            }

            const amount = Number(payout.rows[0].amount)

            const balance = await luckyBirdGiveSessionBalance(client, session)

            if (!Number(balance.entries)) {
                await client.query('ROLLBACK')
                return luckyBirdGiveFail(
                    res,
                    409,
                    'Enter or confirm opening cash before paying a Lucky Bird.'
                )
            }

            if (Number(balance.balance) < amount) {
                await client.query('ROLLBACK')
                return luckyBirdGiveFail(
                    res,
                    409,
                    `Insufficient session cash. Available: $${Number(balance.balance).toFixed(2)}`
                )
            }

            const image = await uploadLuckyBirdImage(req.file.buffer)

            const award = await client.query(`
                INSERT INTO "LuckyBirdAwards"
                (
                    "LocationId",
                    "EmployeeSessionId",
                    "EmployeeId",
                    "LuckyBirdId",
                    "LuckyBirdPayoutId",
                    "LuckyBirdName",
                    "PayoutDescription",
                    "MachineId",
                    "CustomerId",
                    "Amount",
                    "ImageUrl",
                    "CreatedBy"
                )
                VALUES
                ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
                RETURNING
                    "ID" AS id,
                    "CreatedAt" AS "createdAt"
            `, [
                session.LocationId,
                session.ID,
                session.UserId,
                payout.rows[0].luckyBirdId,
                payout.rows[0].payoutId,
                payout.rows[0].luckyBirdName,
                payout.rows[0].payoutDescription,
                machineId,
                customerId,
                amount,
                image.secure_url,
                session.UserId
            ])

            await client.query('COMMIT')

            const customerName =
                `${customer.rows[0].Firstname || ''} ${customer.rows[0].Lastname || ''}`.trim()

            return luckyBirdGiveOk(
                res,
                {
                    id: award.rows[0].id,
                    createdAt: award.rows[0].createdAt,
                    luckyBirdId: payout.rows[0].luckyBirdId,
                    luckyBirdName: payout.rows[0].luckyBirdName,
                    payoutId: payout.rows[0].payoutId,
                    payoutDescription: payout.rows[0].payoutDescription,
                    machineId,
                    machineNumber: machine.rows[0].MachineNumber,
                    customerId,
                    customerName,
                    amount,
                    imageUrl: image.secure_url
                },
                'Lucky Bird saved and deducted from your employee session.'
            )
        } catch (error) {
            try {
                await client.query('ROLLBACK')
            } catch {
                // Transaction may not have started.
            }

            console.error('Lucky Bird give save:', error)
            return luckyBirdGiveFail(res, 500, 'Unable to save Lucky Bird.')
        } finally {
            client.release()
        }
    }
)

// ============================================================
// GET ALL LUCKY BIRDES BY LOCATION
// ============================================================

router.get(
    '/',
    requirePermission('luckybird.read'),
    async (req, res) => {
        try {
            const locationId =
                Number(
                    req.query.locationid
                )

            if (!locationId) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Location is required.'
                })
            }

            const result =
                await pool.query(
                    `
                    SELECT
                        b."ID" AS "id",
                        b."Name" AS "name",
                        b."IsActive" AS "isActive",

                        COUNT(
                            DISTINCT bp."ID"
                        )::integer
                            AS "payoutCount",

                        COUNT(
                            DISTINCT sb."ID"
                        )::integer
                            AS "blockCount",

                        COALESCE(
                            BOOL_AND(
                                sb."IsAllDay"
                            ),
                            false
                        )
                            AS "allDay"

                    FROM "LuckyBird" b

                    LEFT JOIN "LuckyBirdPayout" bp
                        ON bp."LuckyBirdId" =
                           b."ID"

                    LEFT JOIN "LuckyBirdScheduleBlock" sb
                        ON sb."LuckyBirdId" =
                           b."ID"

                    WHERE
                        b."LocationId" = $1

                    GROUP BY
                        b."ID",
                        b."Name",
                        b."IsActive"

                    ORDER BY
                        b."Name"
                    `,
                    [
                        locationId
                    ]
                )

            return res.status(200).json({
                success: true,
                code: 20000,
                message:
                    'Lucky Birds retrieved successfully.',
                data:
                    result.rows
            })
        } catch (error) {
            console.error(
                'Get luckyBirds error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to retrieve luckyBirds.'
            })
        }
    }
)

// ============================================================
// GET SINGLE LUCKY BIRD
// ============================================================

router.get(
    '/:id',
    requirePermission('luckybird.read'),
    async (req, res) => {
        try {
            const luckyBirdId =
                Number(
                    req.params.id
                )

            if (!luckyBirdId) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Invalid luckybird.'
                })
            }

            const luckyBirdResult =
                await pool.query(
                    `
                    SELECT
                        "ID"
                            AS "id",

                        "Name"
                            AS "name",

                        "IsActive"
                            AS "isActive",

                        "LocationId"
                            AS "locationId",

                        "DateCreated"
                            AS "dateCreated",

                        "DateUpdated"
                            AS "dateUpdated"

                    FROM "LuckyBird"

                    WHERE
                        "ID" = $1
                    `,
                    [
                        luckyBirdId
                    ]
                )

            if (
                luckyBirdResult.rowCount === 0
            ) {
                return res.status(404).json({
                    success: false,
                    code: 40400,
                    message:
                        'Lucky Bird not found.'
                })
            }

            const payoutResult =
                await pool.query(
                    `
                    SELECT
                        "ID"
                            AS "id",

                        "Description"
                            AS "description",

                        "Amount"::double precision
                            AS "amount",

                        "SortOrder"
                            AS "sortOrder"

                    FROM "LuckyBirdPayout"

                    WHERE
                        "LuckyBirdId" = $1

                    ORDER BY
                        "SortOrder",
                        "ID"
                    `,
                    [
                        luckyBirdId
                    ]
                )

            const scheduleResult =
                await pool.query(
                    `
                    SELECT
                        sb."ID"
                            AS "id",

                        sb."IsAllDay"
                            AS "isAllDay",

                        sb."StartTime"
                            AS "startTime",

                        sb."EndTime"
                            AS "endTime",

                        sb."EndDayOffset"
                            AS "endDayOffset",

                        sb."SortOrder"
                            AS "sortOrder",

                        COALESCE(
                            ARRAY_AGG(
                                sd."DayOfWeek"
                                ORDER BY
                                    sd."DayOfWeek"
                            )
                            FILTER (
                                WHERE
                                    sd."DayOfWeek"
                                        IS NOT NULL
                            ),
                            '{}'
                        )
                            AS "days"

                    FROM
                        "LuckyBirdScheduleBlock" sb

                    LEFT JOIN
                        "LuckyBirdScheduleDay" sd

                        ON
                            sd."ScheduleBlockId" =
                                sb."ID"

                    WHERE
                        sb."LuckyBirdId" = $1

                    GROUP BY
                        sb."ID"

                    ORDER BY
                        sb."SortOrder",
                        sb."ID"
                    `,
                    [
                        luckyBirdId
                    ]
                )

            return res.status(200).json({
                success: true,
                code: 20000,
                message:
                    'Lucky Bird retrieved successfully.',

                data: {
                    ...luckyBirdResult.rows[0],

                    payouts:
                        payoutResult.rows,

                    scheduleBlocks:
                        scheduleResult.rows
                }
            })
        } catch (error) {
            console.error(
                'Get lucky bird error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to retrieve luckybird.'
            })
        }
    }
)

// ============================================================
// CREATE LUCKY BIRD
// ============================================================

router.post(
    '/',
    requirePermission('luckybird.create'),
    async (req, res) => {
        const client =
            await pool.connect()

        try {
            const {
                name,
                isActive = true,
                locationId,
                payouts = [],
                scheduleBlocks = []
            } = req.body

            const validationError =
                validateLuckyBirdPayload({
                    name,
                    locationId,
                    payouts,
                    scheduleBlocks,
                    requireLocation: true
                })

            if (validationError) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        validationError
                })
            }

            await client.query(
                'BEGIN'
            )

            const luckyBirdResult =
                await client.query(
                    `
                    INSERT INTO "LuckyBird"
                    (
                        "Name",
                        "IsActive",
                        "LocationId"
                    )
                    VALUES
                    (
                        $1,
                        $2,
                        $3
                    )
                    RETURNING
                        "ID" AS "id"
                    `,
                    [
                        name.trim(),
                        Boolean(isActive),
                        Number(locationId)
                    ]
                )

            const luckyBirdId =
                luckyBirdResult.rows[0].id

            await insertLuckyBirdPayouts(
                client,
                luckyBirdId,
                payouts
            )

            await insertLuckyBirdScheduleBlocks(
                client,
                luckyBirdId,
                scheduleBlocks
            )

            await client.query(
                'COMMIT'
            )

            return res.status(201).json({
                success: true,
                code: 20000,
                message:
                    'Lucky Bird created successfully.',

                data: {
                    id:
                        luckyBirdId
                }
            })
        } catch (error) {
            await client.query(
                'ROLLBACK'
            )

            console.error(
                'Create lucky bird error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to create luckybird.'
            })
        } finally {
            client.release()
        }
    }
)

// ============================================================
// UPDATE LUCKY BIRD
// ============================================================

router.put(
    '/:id',
    requirePermission('luckybird.update'),
    async (req, res) => {
        const client =
            await pool.connect()

        try {
            const luckyBirdId =
                Number(
                    req.params.id
                )

            if (!luckyBirdId) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Invalid luckybird.'
                })
            }

            const {
                name,
                isActive,
                payouts = [],
                scheduleBlocks = []
            } = req.body

            const validationError =
                validateLuckyBirdPayload({
                    name,
                    payouts,
                    scheduleBlocks,
                    requireLocation: false
                })

            if (validationError) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        validationError
                })
            }

            await client.query(
                'BEGIN'
            )

            const updateResult =
                await client.query(
                    `
                    UPDATE "LuckyBird"

                    SET
                        "Name" = $1,

                        "IsActive" = $2,

                        "DateUpdated" =
                            NOW()

                    WHERE
                        "ID" = $3
                    `,
                    [
                        name.trim(),
                        Boolean(isActive),
                        luckyBirdId
                    ]
                )

            if (
                updateResult.rowCount === 0
            ) {
                await client.query(
                    'ROLLBACK'
                )

                return res.status(404).json({
                    success: false,
                    code: 40400,
                    message:
                        'Lucky Bird not found.'
                })
            }

            // Delete old payout rows
            await client.query(
                `
                DELETE FROM "LuckyBirdPayout"
                WHERE
                    "LuckyBirdId" = $1
                `,
                [
                    luckyBirdId
                ]
            )

            /*
             * LuckyBirdScheduleDay rows are automatically deleted
             * because LuckyBirdScheduleDay -> LuckyBirdScheduleBlock
             * uses ON DELETE CASCADE.
             */
            await client.query(
                `
                DELETE FROM "LuckyBirdScheduleBlock"
                WHERE
                    "LuckyBirdId" = $1
                `,
                [
                    luckyBirdId
                ]
            )

            await insertLuckyBirdPayouts(
                client,
                luckyBirdId,
                payouts
            )

            await insertLuckyBirdScheduleBlocks(
                client,
                luckyBirdId,
                scheduleBlocks
            )

            await client.query(
                'COMMIT'
            )

            return res.status(200).json({
                success: true,
                code: 20000,
                message:
                    'Lucky Bird saved successfully.'
            })
        } catch (error) {
            await client.query(
                'ROLLBACK'
            )

            console.error(
                'Update lucky bird error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to save luckybird.'
            })
        } finally {
            client.release()
        }
    }
)

// ============================================================
// ENABLE / DISABLE LUCKY BIRD
// ============================================================

router.patch(
    '/:id/status',
    requirePermission('luckybird.update'),
    async (req, res) => {
        try {
            const luckyBirdId =
                Number(
                    req.params.id
                )

            const {
                isActive
            } = req.body

            if (!luckyBirdId) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Invalid luckybird.'
                })
            }

            if (
                typeof isActive !==
                'boolean'
            ) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Status must be true or false.'
                })
            }

            const result =
                await pool.query(
                    `
                    UPDATE "LuckyBird"

                    SET
                        "IsActive" = $1,

                        "DateUpdated" =
                            NOW()

                    WHERE
                        "ID" = $2
                    `,
                    [
                        isActive,
                        luckyBirdId
                    ]
                )

            if (
                result.rowCount === 0
            ) {
                return res.status(404).json({
                    success: false,
                    code: 40400,
                    message:
                        'Lucky Bird not found.'
                })
            }

            return res.status(200).json({
                success: true,
                code: 20000,

                message:
                    isActive
                        ? 'Lucky Bird activated successfully.'
                        : 'Lucky Bird deactivated successfully.'
            })
        } catch (error) {
            console.error(
                'Lucky Bird status error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to update lucky bird status.'
            })
        }
    }
)

// ============================================================
// DELETE LUCKY BIRD
// ============================================================

router.delete(
    '/:id',
    requirePermission('luckybird.delete'),
    async (req, res) => {
        try {
            const luckyBirdId =
                Number(
                    req.params.id
                )

            if (!luckyBirdId) {
                return res.status(400).json({
                    success: false,
                    code: 40000,
                    message:
                        'Invalid luckybird.'
                })
            }

            const result =
                await pool.query(
                    `
                    DELETE FROM "LuckyBird"
                    WHERE
                        "ID" = $1
                    `,
                    [
                        luckyBirdId
                    ]
                )

            if (
                result.rowCount === 0
            ) {
                return res.status(404).json({
                    success: false,
                    code: 40400,
                    message:
                        'Lucky Bird not found.'
                })
            }

            return res.status(200).json({
                success: true,
                code: 20000,
                message:
                    'Lucky Bird deleted successfully.'
            })
        } catch (error) {
            console.error(
                'Delete lucky bird error:',
                error
            )

            return res.status(500).json({
                success: false,
                code: 50000,
                message:
                    'Unable to delete luckybird.'
            })
        }
    }
)

module.exports = router